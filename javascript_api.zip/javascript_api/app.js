/* imports starts */
var express = require('express');
var route = require('./route.js');
var bodyParser = require('body-parser');
var app=express();
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())

/* post request to invoke transaction */
app.post('/invoke', function(req, res){
   route.invoke(req,res);
});

/* GET request to query all cars information */
app.get('/query/queryAllCars',function(req,res){
   route.queryAllCars(req,res);
})

/* GET request to query particular car information */
app.get('/query/queryCar/:arg1',function(req,res){
   route.queryCar(req,res);
})

var server = app.listen(8080, function() {

  console.log('Express server listening on port 8080');

});

module.exports = app;